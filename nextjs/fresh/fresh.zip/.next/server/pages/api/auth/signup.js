"use strict";
(() => {
var exports = {};
exports.id = 280;
exports.ids = [280];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 3711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _util_database__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8294);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_1__);


async function handler(req, res) {
  if (req.method == 'POST') {
    if (req.body.email == '' || req.body.name == '' || req.body.password == '') {
      return res.status(400).json('....');
    } else {
      let hash = await bcrypt__WEBPACK_IMPORTED_MODULE_1___default().hash(req.body.password, 10);
      req.body.password = hash;
      req.body.roll = 'user';
      let db = (await _util_database__WEBPACK_IMPORTED_MODULE_0__/* .connectDB */ .u).db('forum');
      let result = await db.collection('user_cred').findOne({
        email: req.body.email
      });

      if (result) {
        return res.status(400).json('다른 이메일을 사용하세요');
      }

      await db.collection('user_cred').insertOne(req.body);
      res.status(200).json('가입성공');
    }
  }
}

/***/ }),

/***/ 8294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ connectDB)
/* harmony export */ });
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);

const url = 'mongodb+srv://my0990:134613@cluster0.0iveuyt.mongodb.net/';
const options = {
  useNewUrlParser: true
};
let connectDB;

if (false) {} else {
  connectDB = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(url, options).connect();
}



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3711));
module.exports = __webpack_exports__;

})();